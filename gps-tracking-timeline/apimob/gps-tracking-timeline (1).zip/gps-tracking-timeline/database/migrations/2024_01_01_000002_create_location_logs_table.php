<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('location_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('employee_id')->constrained()->cascadeOnDelete();
            $table->decimal('latitude', 10, 7);
            $table->decimal('longitude', 10, 7);
            // Optional human-readable label if reverse-geocoded on the device
            // (e.g. "Office", "Customer Location A"). Left null for raw pings.
            $table->string('place_name')->nullable();
            $table->unsignedInteger('accuracy_meters')->nullable();
            $table->unsignedTinyInteger('battery_level')->nullable();
            $table->dateTime('recorded_at');
            $table->timestamps();

            $table->index(['employee_id', 'recorded_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('location_logs');
    }
};
